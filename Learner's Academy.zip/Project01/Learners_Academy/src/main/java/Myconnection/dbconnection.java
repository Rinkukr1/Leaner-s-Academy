package Myconnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class dbconnection {
	public static Connection getcon() {
		Connection cn=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/project01","root","root");
			
		}catch(Exception e) {
		e.getMessage();	
		}	
		return cn;
	}
}
