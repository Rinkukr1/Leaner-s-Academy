package tables;

public class classes {
	private int cls_id;
	private String cls_name;
	
	public int getCls_id() {
		return cls_id;
	}
	public void setCls_id(int cls_id) {
		this.cls_id = cls_id;
	}
	public String getCls_name() {
		return cls_name;
	}
	public void setCls_name(String cls_name) {
		this.cls_name = cls_name;
	}
	
	
}
