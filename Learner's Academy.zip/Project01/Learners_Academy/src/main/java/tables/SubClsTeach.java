package tables;

public class SubClsTeach {
	int sub_id;
	int cls_id;
	int teach_id;
	String sub_name;
	String cls_name;
	String teacg_name;
	
	
	public String getSub_name() {
		return sub_name;
	}
	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}
	public String getCls_name() {
		return cls_name;
	}
	public void setCls_name(String cls_name) {
		this.cls_name = cls_name;
	}
	public String getTeacg_name() {
		return teacg_name;
	}
	public void setTeacg_name(String teacg_name) {
		this.teacg_name = teacg_name;
	}
	public int getSub_id() {
		return sub_id;
	}
	public void setSub_id(int sub_id) {
		this.sub_id = sub_id;
	}
	public int getCls_id() {
		return cls_id;
	}
	public void setCls_id(int cls_id) {
		this.cls_id = cls_id;
	}
	public int getTeach_id() {
		return teach_id;
	}
	public void setTeach_id(int teach_id) {
		this.teach_id = teach_id;
	}	
}
