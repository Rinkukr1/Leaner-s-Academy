package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.Student;

public class StudentOperations {
	PreparedStatement ps=null;
	public String AddStu(Student st) {
		String result="fail";
		try {
			ps=dbconnection.getcon().prepareStatement("insert into students values(?,?,?,?,?)");
			ps.setInt(1, st.getRno());
			ps.setString(2, st.getName());
			ps.setString(3, st.getGender());
			ps.setString(4, st.getLocation());
			ps.setInt(5, st.getClsid());
			
			int res=ps.executeUpdate();
			if(res>=1) {
				result="success";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			result=e.getMessage();
		}
		return result;
	}
	public List<Student> showall(){
		List<Student> ls=null;
		Student st=null;
		try {
			ps=dbconnection.getcon().prepareStatement("select * from students");
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<Student>();		
			while(res.next()) {
				st=new Student();
				st.setRno(res.getInt("rno"));
				st.setName(res.getString("stu_name"));
				st.setGender(res.getString("gender"));
				st.setLocation(res.getString("location"));
				st.setClsid(res.getInt("class_id"));
				
				ls.add(st);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}
	
	public List<Student> showWithClass(String class_name){
		List<Student> ls=null;
		Student st=null;
		try {
			ps=dbconnection.getcon().prepareStatement("SELECT cl.class_name,st.rno,st.stu_name,st.gender,st.location\r\n"
					+ "FROM students AS st \r\n"
					+ "\r\n"
					+ "JOIN classes AS cl \r\n"
					+ "ON cl.class_id = st.class_id\r\n"
					+ "\r\n"
					+ "where cl.class_name=?");
			ps.setString(1, class_name);
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<Student>();		
			while(res.next()) {
				st=new Student();
				st.setRno(res.getInt("rno"));
				st.setName(res.getString("stu_name"));
				st.setGender(res.getString("gender"));
				st.setLocation(res.getString("location"));
				st.setClass_name(res.getString("class_name"));
				
				ls.add(st);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}
	
	
	
	public List<Student> showAllStudents(){
		List<Student> ls=null;
		Student st=null;
		try {
			ps=dbconnection.getcon().prepareStatement("SELECT cl.class_name,st.rno,st.stu_name,st.gender,st.location\r\n"
					+ "FROM students AS st \r\n"
					+ "\r\n"
					+ "JOIN classes AS cl \r\n"
					+ "ON cl.class_id = st.class_id\r\n"
					+ "\r\n");
			
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<Student>();		
			while(res.next()) {
				st=new Student();
				st.setRno(res.getInt("rno"));
				st.setName(res.getString("stu_name"));
				st.setGender(res.getString("gender"));
				st.setLocation(res.getString("location"));
				st.setClass_name(res.getString("class_name"));
				
				ls.add(st);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}

}
