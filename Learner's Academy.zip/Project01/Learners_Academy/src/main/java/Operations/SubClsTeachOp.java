package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.SubClsTeach;
import tables.SubjectClass;

public class SubClsTeachOp {
	PreparedStatement ps=null;
	
	public String Mapped(SubClsTeach sct) {
		String result=null;
		try {
			ps=dbconnection.getcon().prepareStatement("insert into teacherSubjectClass values(?,?,?)");
			
		    ps.setInt(1, sct.getCls_id());
			ps.setInt(2,sct.getSub_id() );
			ps.setInt(3, sct.getTeach_id());
			
			int res=ps.executeUpdate();
			if(res>=1) {
				result="success";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			result=e.getMessage();
		}
		return result;
	}
	
	public List<SubClsTeach> showall(){
		List<SubClsTeach> ls=null;
		SubClsTeach sct=null;
		try {
			ps=dbconnection.getcon().prepareStatement("SELECT sub.subject_name,cl.class_name,tch.teacher_name FROM teachersubjectclass AS sbcl "
					+ "JOIN subject AS sub ON sub.subject_id = sbcl.subject_id "
					+ "JOIN classes AS cl ON cl.class_id = sbcl.class_id "
					+ "JOIN teachers AS tch ON tch.teacher_id = sbcl.teacher_id");
			
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<SubClsTeach>();		
			while(res.next()) {
				sct=new SubClsTeach();
				sct.setCls_name(res.getString("class_name"));
				sct.setSub_name(res.getString("subject_name"));
				sct.setTeacg_name(res.getString("teacher_name"));
				
				ls.add(sct);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}

}
