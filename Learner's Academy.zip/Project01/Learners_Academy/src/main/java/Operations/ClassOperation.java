package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.Student;
import tables.classes;

public class ClassOperation {
	public String Addclass(classes c) {
		PreparedStatement ps=null;
		String result="fail";
		try {
			ps=dbconnection.getcon().prepareStatement("insert into classes values(?,?)");
			ps.setInt(1, c.getCls_id());
			ps.setString(2, c.getCls_name());
			
			int res=ps.executeUpdate();
			if(res>=1) {
				result="success";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			result=e.getMessage();
		}

		
		return result;
	}
	
	public List<classes> showall(){
		List<classes> ls=null;
		classes cls=null;
		PreparedStatement ps=null;
		try {
			ps=dbconnection.getcon().prepareStatement("select * from classes");
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<classes>();		
			while(res.next()) {
				cls=new classes();
				cls.setCls_id(res.getInt("class_id"));
				cls.setCls_name(res.getString("class_name"));
				
				ls.add(cls);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}
	
	public List<classes> name(){
		List<classes> ls=null;
		classes cls=null;
		PreparedStatement ps=null;
		try {
			ps=dbconnection.getcon().prepareStatement("select * from classes");
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<classes>();		
			while(res.next()) {
				cls=new classes();
				cls.setCls_id(res.getInt("class_id"));
				cls.setCls_name(res.getString("class_name"));
				
				ls.add(cls);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}
	

}
