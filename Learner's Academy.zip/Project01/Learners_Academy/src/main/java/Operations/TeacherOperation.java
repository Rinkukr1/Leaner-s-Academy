package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.teachers;

public class TeacherOperation {
	PreparedStatement ps=null;
	
	public String AddTeacher(teachers teach) {
		String result=null;
		try {
			ps=dbconnection.getcon().prepareStatement("insert into teachers values(?,?,?,?)");
			ps.setInt(1, teach.getTeacher_id());
			ps.setString(2, teach.getTeacher_name());
			ps.setString(3, teach.getLocation());
			ps.setString(4, teach.getPhone());
			
			int res=ps.executeUpdate();
			if(res>=1) {
				result="success";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			result=e.getMessage();
		}
		
		return result;
	}
	
	public List<teachers> showall(){
		List<teachers> ls=null;
		teachers tch=null;
		PreparedStatement ps=null;
		try {
			ps=dbconnection.getcon().prepareStatement("select * from teachers");
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<teachers>();		
			while(res.next()) {
				tch=new teachers();
				tch.setTeacher_id(res.getInt("teacher_id"));
				tch.setTeacher_name(res.getString("teacher_name"));
				tch.setLocation(res.getString("location"));
				tch.setPhone(res.getString("phone"));
				
				ls.add(tch);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}

}
