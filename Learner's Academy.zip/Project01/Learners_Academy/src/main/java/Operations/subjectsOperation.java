package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.subjects;

public class subjectsOperation {
	PreparedStatement ps=null;
	
	public String AddSub(subjects sub) {
		String result=null;
		try {
			ps=dbconnection.getcon().prepareStatement("insert into subject values(?,?)");
			ps.setInt(1, sub.getSub_id());
			ps.setString(2, sub.getSub_name());
			
			int res=ps.executeUpdate();
			if(res>=1) {
				result="success";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			result=e.getMessage();
		}
		
		return result;
	}
	
	public List<subjects> showall(){
		List<subjects> ls=null;
		subjects sub=null;
		PreparedStatement ps=null;
		try {
			ps=dbconnection.getcon().prepareStatement("select * from subject");
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<subjects>();		
			while(res.next()) {
				sub=new subjects();
				sub.setSub_id(res.getInt("subject_id"));
				sub.setSub_name(res.getString("subject_name"));
				
				ls.add(sub);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
}
}
