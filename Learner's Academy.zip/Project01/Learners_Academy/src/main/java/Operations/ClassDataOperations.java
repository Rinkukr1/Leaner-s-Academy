package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.ClassData;

public class ClassDataOperations {
	PreparedStatement ps=null;
	
	public List<ClassData> showall(String class_name){
		List<ClassData> ls=null;
		ClassData cd=null;
		try {
			ps=dbconnection.getcon().prepareStatement("SELECT cl.class_name,sub.subject_name,tch.teacher_name,tch.location,tch.phone\r\n"
					+ "FROM teachersubjectclass AS tsc \r\n"
					+ "JOIN teachers AS tch \r\n"
					+ "ON tch.teacher_id = tsc.teacher_id\r\n"
					+ "\r\n"
					+ "JOIN subject AS sub \r\n"
					+ "ON sub.subject_id = tsc.subject_id\r\n"
					+ "\r\n"
					+ "JOIN classes AS cl \r\n"
					+ "ON cl.class_id = tsc.class_id\r\n"
					+ "where cl.class_name=?");
			ps.setString(1, class_name);
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<ClassData>();		
			while(res.next()) {
				cd=new ClassData();
				cd.setCls_name(res.getString("class_name"));
				cd.setSub_name(res.getString("subject_name"));
				cd.setTech_name(res.getString("teacher_name"));
				cd.setPhone(res.getString("phone"));
				cd.setLocation(res.getString("location"));
				
				ls.add(cd);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
		
		
	}
}
