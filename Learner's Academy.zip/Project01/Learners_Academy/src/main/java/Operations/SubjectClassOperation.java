package Operations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Myconnection.dbconnection;
import tables.SubjectClass;

public class SubjectClassOperation {
	PreparedStatement ps=null;
	public String Add(SubjectClass subcl) {
		String result=null;
		try {
			ps=dbconnection.getcon().prepareStatement("insert into subjectClass values(?,?)");
			ps.setInt(1, subcl.getSubject_id());
			ps.setInt(2, subcl.getClass_id());
			
			int res=ps.executeUpdate();
			if(res>=1) {
				result="success";
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			result=e.getMessage();
		}
		return result;
	}
	public List<SubjectClass> showall(){
		List<SubjectClass> ls=null;
		SubjectClass scl=null;
		try {
			ps=dbconnection.getcon().prepareStatement("SELECT sub.subject_name,cl.class_name FROM subjectclass AS sbcl JOIN subject AS sub ON sub.subject_id = sbcl.subject_id JOIN classes AS cl ON cl.class_id = sbcl.class_id");
			
			ResultSet res=ps.executeQuery();
			ls=new ArrayList<SubjectClass>();		
			while(res.next()) {
				scl=new SubjectClass();
				scl.setClass_name(res.getString("class_name"));
				scl.setSub_name(res.getString("subject_name"));
				
				ls.add(scl);
			}
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		return ls;
	}

}
