package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Operations.SubClsTeachOp;
import tables.SubClsTeach;

/**
 * Servlet implementation class ShowSubClsTeach
 */
@WebServlet("/ShowSubClsTeach")
public class ShowSubClsTeach extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowSubClsTeach() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		SubClsTeachOp sctop=new SubClsTeachOp();
		List<SubClsTeach> ls=sctop.showall();
		
		out.print("<h1 align='center'>");
		out.print("All The Classes That Are Mapped With Subjects");
		out.print("</h1>");
		out.print("<hr>");
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Class Name</th><th>Subject Name</th><th>Teacher Name</th></tr>");
		
		for(SubClsTeach sct : ls)
		{
			out.print("<tr>");
			out.print("<td>" + sct.getCls_name() + "</td>");
			out.print("<td>" + sct.getSub_name() + "</td>");
			out.print("<td>" + sct.getTeacg_name() + "</td>");
			out.print("</tr>");
		}
		out.print("</table>");
		out.print("<hr>");
		out.print("<h2>");
		out.print("<a href='SubClsTeach.jsp'>Mapped More Classes And Subject With Teacher</a>");
		out.print("</h1>");
	}

}


