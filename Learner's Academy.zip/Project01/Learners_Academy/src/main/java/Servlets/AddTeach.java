package Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Operations.TeacherOperation;
import tables.teachers;

/**
 * Servlet implementation class AddTeach
 */
@WebServlet("/AddTeach")
public class AddTeach extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddTeach() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		
		int id=Integer.parseInt(request.getParameter("teacherId"));
		String name=request.getParameter("teacherName");
		String phone=request.getParameter("phoneNumber");
		String location=request.getParameter("location");
		
		teachers tr=new teachers();
		tr.setTeacher_id(id);
		tr.setTeacher_name(name);
		tr.setPhone(phone);
		tr.setLocation(location);
		
		TeacherOperation trop=new TeacherOperation();
		
		String res=trop.AddTeacher(tr);
		
		session.setAttribute("user", "Teacher");
		session.setAttribute("url", "AddTeach.html");
		session.setAttribute("error", res);
		
		if(res=="success") {
			response.sendRedirect("added");
		}else {
			response.sendRedirect("failed");
		}
	}

}
