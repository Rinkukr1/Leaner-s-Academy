package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Operations.StudentOperations;
import tables.Student;

/**
 * Servlet implementation class welcome
 */
@WebServlet("/welcome")
public class welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public welcome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		StudentOperations stop=new StudentOperations();
		List<Student> ls=stop.showall();
		out.print("<h1 align='center'>");
		out.print("Wecome To Administrator");
		out.print("</h1>");
		out.print("<hr />");
		out.print("<p style='text-align:center;width:100%'>");
		out.print("<a href='AddStudent.jsp'>New Student</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='AddSub.html'>Add Subject</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='AddTeach.html'>Add New Teacher</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='AddClass.html'>Add New Class</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='SubjectClass.jsp'>mapp class-subject</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='SubClsTeach.jsp'>mapp class/subject with teacher</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='ShowClassData.jsp'>Check Class Data</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='Log-in.html'>Logout</a>");
		out.print("</p>");
		out.print("<hr />");
		
		
		
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Roll No</th><th>Student Name</th><th>Gender</th><th>Location</th><th>Class_id</th></tr>");
		
		for(Student st : ls)
		{
			out.print("<tr>");
			out.print("<td>" + st.getRno() + "</td>");
			out.print("<td>" + st.getName() + "</td>");
			out.print("<td>" + st.getGender() + "</td>");
			out.print("<td>" + st.getLocation() + "</td>");
			out.print("<td>" + st.getClsid() + "</td>");
			out.print("</tr>");
		}
		out.print("</table>");
	}

}
