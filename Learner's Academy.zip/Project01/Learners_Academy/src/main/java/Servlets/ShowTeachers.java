package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Operations.TeacherOperation;
import Operations.subjectsOperation;
import tables.subjects;
import tables.teachers;

/**
 * Servlet implementation class ShowTeachers
 */
@WebServlet("/ShowTeachers")
public class ShowTeachers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowTeachers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		TeacherOperation top=new TeacherOperation();
		List<teachers> ls=top.showall();
		
		
		out.print("<h1 align='center'>");
		out.print("All Teachers With Thier ID");
		out.print("</h1>");
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Teacher ID</th><th>Teacher Name</th><th>Phone</th><th>Location</th></tr>");
		
		for(teachers tch : ls)
		{
			out.print("<tr>");
			out.print("<td>" + tch.getTeacher_id() + "</td>");
			out.print("<td>" + tch.getTeacher_name() + "</td>");
			out.print("<td>" + tch.getPhone() + "</td>");
			out.print("<td>" + tch.getLocation() + "</td>");
			out.print("</tr>");
		}
		out.print("</table>");
		out.print("<h2>");
		out.print("<a href='AddTeach.html'>ADD NEW TEACHER</a>");
		out.print("</h1>");
	}


	}
