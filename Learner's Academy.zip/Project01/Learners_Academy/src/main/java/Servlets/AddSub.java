package Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Operations.subjectsOperation;
import tables.subjects;

/**
 * Servlet implementation class AddSub
 */
@WebServlet("/AddSub")
public class AddSub extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddSub() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		HttpSession session=request.getSession();
		session.setAttribute("user", "Subject");
		session.setAttribute("url", "AddSub.html");
		subjects sub=new subjects();
		sub.setSub_id(id);
		sub.setSub_name(name);
		
		subjectsOperation subop=new subjectsOperation();
		String res=subop.AddSub(sub);
		if(res=="success") {
			response.sendRedirect("added");
		}else {
			response.sendRedirect("failed");
		}
	}

}
