package Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class added
 */
@WebServlet("/added")
public class added extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public added() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		
		String pagename=(String)session.getAttribute("user");
		String pageurl=(String) session.getAttribute("url");
		out.print("<h1 align='center'>");
		out.print(pagename+" Added succefully <br> Add More "+pagename+": "+"<a href="+pageurl+">ADD-MORE</a>");
		out.print("</h1>");
		out.print("<h1 align='center'>");
		out.print("Click Here to Go to Home Page"+"<a href='ShowClassData.jsp'>HOME</a>");
		out.print("</h1>");
	}

}
