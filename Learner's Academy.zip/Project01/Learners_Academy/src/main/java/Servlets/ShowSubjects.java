package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Operations.ClassOperation;
import Operations.subjectsOperation;
import tables.classes;
import tables.subjects;

/**
 * Servlet implementation class ShowSubjects
 */
@WebServlet("/ShowSubjects")
public class ShowSubjects extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowSubjects() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		subjectsOperation subop=new subjectsOperation();
		List<subjects> ls=subop.showall();
		
		
		out.print("<h1 align='center'>");
		out.print("All Subjects With Thier ID");
		out.print("</h1>");
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Subject ID</th><th>Subject Name</th></tr>");
		
		for(subjects sub : ls)
		{
			out.print("<tr>");
			out.print("<td>" + sub.getSub_id() + "</td>");
			out.print("<td>" + sub.getSub_name() + "</td>");
			out.print("</tr>");
		}
		out.print("</table>");
		out.print("<h2>");
		out.print("<a href='AddSub.html'>ADD NEW SUBJECT</a>");
		out.print("</h1>");
	}


}
