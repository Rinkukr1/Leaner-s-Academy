package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Operations.SubjectClassOperation;
import tables.SubjectClass;

/**
 * Servlet implementation class ShowSubjectClass
 */
@WebServlet("/ShowSubjectClass")
public class ShowSubjectClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowSubjectClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		SubjectClassOperation subclop=new SubjectClassOperation();
		List<SubjectClass> ls=subclop.showall();
		
		out.print("<h1 align='center'>");
		out.print("All The Classes That Are Mapped With Subjects");
		out.print("</h1>");
		
		out.print("<hr>");
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Class Name</th><th>Subject Name</th></tr>");
		
		for(SubjectClass scl : ls)
		{
			out.print("<tr>");
			out.print("<td>" + scl.getClass_name() + "</td>");
			out.print("<td>" + scl.getSub_name() + "</td>");
			out.print("</tr>");
		}
		out.print("</table>");
		out.print("<hr>");
		out.print("<h2>");
		out.print("<a href='SubjectClass.jsp'>Mapped More Classes with Subject</a>");
		out.print("</h1>");
	}
	
}
