package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Operations.ClassOperation;
import tables.Student;
import tables.classes;

/**
 * Servlet implementation class ShowClasses
 */
@WebServlet("/ShowClasses")
public class ShowClasses extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowClasses() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		ClassOperation clop=new ClassOperation();
		List<classes> ls=clop.showall();
		
		out.print("<h1 align='center'>");
		out.print("All Classes With Thier ID");
		out.print("</h1>");
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Class ID</th><th>Class Nmae</th></tr>");
		
		for(classes cls : ls)
		{
			out.print("<tr>");
			out.print("<td>" + cls.getCls_id() + "</td>");
			out.print("<td>" + cls.getCls_name() + "</td>");
			out.print("</tr>");
		}
		out.print("</table>");
		out.print("<h2>");
		out.print("<a href='AddClass.html'>ADD NEW CLASS</a>");
		out.print("</h1>");
	}

	}


