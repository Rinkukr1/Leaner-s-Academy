package Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Operations.StudentOperations;
import tables.Student;

@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		session.setAttribute("user", "Student");
		session.setAttribute("url", "Addstudent.html");
		
		
		String rno=request.getParameter("rno");
		String name=request.getParameter("Name");
		String gender=request.getParameter("gender");
		String location=request.getParameter("location");
		int clsid=Integer.parseInt(request.getParameter("class"));
		
		Student st=new Student();
		st.setRno(Integer.parseInt(rno));
		st.setName(name);
		st.setGender(gender);
		st.setLocation(location);
		st.setClsid(clsid);
		
		StudentOperations stop=new StudentOperations();
		
		String res=stop.AddStu(st);
		if(res=="success") {
			response.sendRedirect("added");
		}
		else {
			response.sendRedirect("failed");;
		}
	}

}
